self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "30b1948b14176d06289f3823b3eff931",
    "url": "/index.html"
  },
  {
    "revision": "4f2e52d02bb6da92883b",
    "url": "/static/css/main.972bf737.chunk.css"
  },
  {
    "revision": "34db18b55fc63f68052c",
    "url": "/static/js/2.af7a5197.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.af7a5197.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4f2e52d02bb6da92883b",
    "url": "/static/js/main.fee6c06c.chunk.js"
  },
  {
    "revision": "01b91967d4d1015b7620",
    "url": "/static/js/runtime-main.99f0a852.js"
  },
  {
    "revision": "2621b339843b5ad2fac8b5a568cf260b",
    "url": "/static/media/delete.2621b339.svg"
  },
  {
    "revision": "b6eac395b9ca08467ce2467ec3114b8f",
    "url": "/static/media/grip.b6eac395.svg"
  },
  {
    "revision": "146b87130c4f832eb55cd2922f292ed1",
    "url": "/static/media/play.146b8713.svg"
  },
  {
    "revision": "ee84cef568f9dbbeaa155dc602c4baf5",
    "url": "/static/media/plus.ee84cef5.svg"
  },
  {
    "revision": "167b122da4e9c4da29c00c7e116c6d8f",
    "url": "/static/media/white-arrow.167b122d.svg"
  }
]);