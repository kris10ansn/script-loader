self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "734ec46e82d3e7774cf83a9e2063a2ee",
    "url": "/index.html"
  },
  {
    "revision": "732f72c6f898c331a913",
    "url": "/static/css/main.7c2b9121.chunk.css"
  },
  {
    "revision": "2a6df21a60d411871abd",
    "url": "/static/js/2.992923d7.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.992923d7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "732f72c6f898c331a913",
    "url": "/static/js/main.b69976f7.chunk.js"
  },
  {
    "revision": "01b91967d4d1015b7620",
    "url": "/static/js/runtime-main.99f0a852.js"
  },
  {
    "revision": "38800d5d7589900385fd5fd7bf2b96ac",
    "url": "/static/media/delete.38800d5d.svg"
  },
  {
    "revision": "7ef00e80bc2026a3e5efd1790fe380ea",
    "url": "/static/media/grip.7ef00e80.svg"
  },
  {
    "revision": "a687ec6d606616a99fa6d7e255761980",
    "url": "/static/media/play.a687ec6d.svg"
  },
  {
    "revision": "02083658f667a2caed8a2508bc6cf0f2",
    "url": "/static/media/plus.02083658.svg"
  },
  {
    "revision": "82e06664b8cb00a453a6aeca1a2c89cf",
    "url": "/static/media/white-arrow.82e06664.svg"
  }
]);